# AVKAS & Co. – BACKEND (host on Render as a Web Service)

Receives the Contact and Career forms and emails them to **heetshah@gmail.com** through Amazon SES.

Endpoints: `POST /api/contact` · `POST /api/career` (multipart, resume PDF/DOC/DOCX ≤ 5 MB) · `GET /api/health` · `GET /api/wake`

## Render settings (New → Web Service → connect the GitHub repo that contains THIS folder)

| Setting | Value |
| --- | --- |
| Runtime | Node |
| Build Command | `npm install` |
| Start Command | `npm start` |
| Health Check Path | `/api/health` |
| Region | Singapore |

### Environment variables (Render → Environment)

| Name | Value |
| --- | --- |
| `NODE_VERSION` | `20` |
| `NODE_ENV` | `production` |
| `CORS_ORIGINS` | optional – `https://avkas.onrender.com`, `https://avkasco.com` and `https://www.avkasco.com` are already allowed by the code; add others only if needed |
| `AWS_ACCESS_KEY_ID` | your IAM key |
| `AWS_SECRET_ACCESS_KEY` | your IAM secret |
| `AWS_REGION` | `ap-south-1` |
| `SES_FROM_EMAIL` | verified sender, e.g. `AVKAS Website <no-reply@avkasco.com>` |
| `SES_TO_EMAIL` | `heetshah@gmail.com` |

## Amazon SES in 5 steps
1. AWS console → SES → choose region **ap-south-1 (Mumbai)**.
2. *Verified identities → Create identity*: verify the **domain** `avkasco.com` (add the 3 DKIM CNAME records it shows; they don't affect your website), or for a quick test verify the email address `heetshah@gmail.com` and use it as `SES_FROM_EMAIL`.
3. New accounts are in the *sandbox* and can only send **to verified addresses**: verify `heetshah@gmail.com` too, or click *Request production access*.
4. IAM → create user `avkas-api-ses` with this policy, then create an access key:
   ```json
   { "Version": "2012-10-17", "Statement": [{ "Effect": "Allow", "Action": ["ses:SendEmail", "ses:SendRawEmail"], "Resource": "*" }] }
   ```
5. Put the key and secret in Render's Environment (never in GitHub).

## Custom domain
In Render → this service → Custom Domains → add `api.avkasco.com`, then at your DNS provider add
`CNAME  api  →  <your-service>.onrender.com`. Do this only after testing on the temporary address.

## Run on your computer
```powershell
npm install
npm start              # http://localhost:4000   (reads .env)
npm run test:api -- http://localhost:4000      # optional: sends 2 real test emails
```
`.env` holds local settings (git-ignored – do not upload it). Fill the two AWS keys in it.

## Notes
* Free Render services sleep after 15 minutes idle and can take up to about a minute to wake – the website's wake request and retry logic handle this, but cannot make it instant.
* Duplicate-email protection is kept in memory (one running instance). It covers normal retries.
